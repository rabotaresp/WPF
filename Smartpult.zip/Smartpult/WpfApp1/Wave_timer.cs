﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp1
{
    class Wave_timer
    {
        static Wave_timer()
        {
            wave_timer = new RoutedCommand("wave_timer", typeof(MainWindow));
        }
        public static RoutedCommand wave_timer { get; set; }
    }
}
