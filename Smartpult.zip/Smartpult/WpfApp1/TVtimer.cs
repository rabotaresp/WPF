﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp1 {
    class TVtimer {
        static TVtimer() {
            timer_tv = new RoutedCommand("timer_tv", typeof(MainWindow));
        }
        public static RoutedCommand timer_tv { get; set; }
    }
}
