﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp1
{
    class Wave_on
    {
        static Wave_on()
        {
            wave_on = new RoutedCommand("wave_on", typeof(MainWindow));
        }
        public static RoutedCommand wave_on { get; set; }
    }
}
