﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp1 {
    class Control_tvoff {
        static Control_tvoff() {
            control_switch_off_tv = new RoutedCommand("control_switch_off_tv", typeof(MainWindow));
        }
        public static RoutedCommand control_switch_off_tv { get; set; }
    }
}

