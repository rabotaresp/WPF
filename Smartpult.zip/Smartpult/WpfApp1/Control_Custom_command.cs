﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace WpfApp1 {
 public   class Control_Custom_command {

        static Control_Custom_command() {
            control_switch_on_tv = new RoutedCommand("control_switch_on_tv", typeof(MainWindow));
        }
        public static RoutedCommand control_switch_on_tv { get; set; }
    }
}
