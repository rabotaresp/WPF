﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using WpfAnimatedGif;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool tvstatus;
        bool mwstatus;
        DispatcherTimer timer_t = new DispatcherTimer();
        DispatcherTimer timer_wave = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();
            slider_Unchecked(null,null);
            timer_t.Tick += new EventHandler(timer_tick);
            timer_wave.Tick += new EventHandler(timer_mw_tick);
            timer_t.Interval = new TimeSpan(0,0,5);
            timer_wave.Interval = new TimeSpan(0, 0, 5);
        }

        private void timer_mw_tick(object sender, EventArgs e)
        {
            wave_off(null, null);
        }

        private void timer_tick(object sender, EventArgs e) {
                control_switch_off_tv(null, null);
        }

        private void control_switch_on_tv(object sender, ExecutedRoutedEventArgs e) {
            var img_gif = new BitmapImage();
            img_gif.BeginInit();
            img_gif.UriSource = new Uri("pack://application:,,,/img/on-TV.gif");
            img_gif.EndInit();
            ImageBehavior.SetAnimatedSource(tvimg, img_gif);
            tvstatus = true;
            //tvimg.Source = new BitmapImage(new Uri("pack://application:,,,/img/TVOn.jpg"));
            //tvstatus = true;
        }

        private void control_switch_off_tv(object sender, ExecutedRoutedEventArgs e) {
            var img_gif = new BitmapImage();
            img_gif.BeginInit();
            img_gif.UriSource = new Uri("pack://application:,,,/img/TVOff.jpg");
            img_gif.EndInit();
            ImageBehavior.SetAnimatedSource(tvimg, img_gif);
            tvstatus = false;
            //tvimg.Source = new BitmapImage(new Uri("pack://application:,,,/img/TVOff.jpg"));
            //tvstatus = false;
            timer_t.Stop();
        }

        private void timer_tv(object sender, ExecutedRoutedEventArgs e) {
            if(tvstatus == true)
                timer_t.Start();        
        }

        private void wave_on(object sender, ExecutedRoutedEventArgs e)
        {
            //mwimg.Source = new BitmapImage(new Uri("pack://application:,,,/img/on_wave.gif"));

            var img_gif = new BitmapImage();
            img_gif.BeginInit();
            img_gif.UriSource = new Uri("pack://application:,,,/img/on_wave.gif");

            img_gif.EndInit();
            ImageBehavior.SetAnimatedSource(mwimg, img_gif);
            mwstatus = true;
        }

        private void wave_off(object sender, ExecutedRoutedEventArgs e)
        {
            var img_gif = new BitmapImage();
            img_gif.BeginInit();
            img_gif.UriSource = new Uri("pack://application:,,,/img/wave_off1.jpg");
            img_gif.EndInit();
            ImageBehavior.SetAnimatedSource(mwimg, img_gif);
            mwstatus = false;
            //mwimg.Source = new BitmapImage(new Uri("pack://application:,,,/img/MicroOff2.jpg"));
            //mwstatus = false;
            timer_wave.Stop();
        }

        private void wave_timer(object sender, ExecutedRoutedEventArgs e)
        {
            if (mwstatus == true)
                timer_wave.Start();
        }

        private void slider_Checked(object sender, RoutedEventArgs e)
        {
            on.Command = Control_Custom_command.control_switch_on_tv;
            off.Command = Control_tvoff.control_switch_off_tv;
            timer.Command = TVtimer.timer_tv;
        }

        private void slider_Unchecked(object sender, RoutedEventArgs e)
        {
            on.Command = Wave_on.wave_on;
            off.Command = Wave_off.wave_off;
            timer.Command = Wave_timer.wave_timer;
        }
    }
}
