﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IP_TCP_IP
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Client_TCP myclient;
        Server_TCP meserver;
        public MainWindow()
        {
            InitializeComponent();
            foreach (IPAddress ip in Dns.GetHostByName(Dns.GetHostName()).AddressList)
            {
                My_IP.Text = "IP " + ip.ToString();
            }
            myclient = new Client_TCP();
            meserver = new Server_TCP();
        }

        private String IPAddressCheck()
        {
            var IPAddr = Dns.GetHostEntry("HostName");
            IPAddress ipString = null;

            foreach (var IP in IPAddr.AddressList)
            {

                if (IPAddress.TryParse(IP.ToString(), out ipString) && IP.AddressFamily == AddressFamily.InterNetwork)
                {
                    break;
                }
            }
            return ipString.ToString();
        }

        private void Connect_click(object sender, EventArgs e)
        {
            myclient.Exchange("192.168.4.67", 1337, My_Client_Listen_txt.Text);
            
        }

        private void Start_Server_btn_click(object sender, RoutedEventArgs e)
        {
            meserver.Start_server();
        }
    }
}
