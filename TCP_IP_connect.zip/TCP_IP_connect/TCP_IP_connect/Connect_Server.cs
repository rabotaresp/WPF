﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TCP_IP_connect
{
    class Connect_Server
    {
        static Server_IP server; // сервер
        static Thread listenThread; // поток для прослушивания
        static void Cust_Connect_Server()
        {
            try
            {
                server = new Server_IP();
                listenThread = new Thread(new ThreadStart(server.Listen));
                listenThread.Start(); //старт потока
            }
            catch (Exception ex)
            {
                server.Disconnect();
                Console.WriteLine(ex.Message);
            }
        }
    }
}
