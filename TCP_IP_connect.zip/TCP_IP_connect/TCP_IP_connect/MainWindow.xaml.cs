﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TCP_IP_connect
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Client_IP client_t;
        Server_IP server_t;
        Connect_Client c_s;
        TcpClient client = new TcpClient();
        public MainWindow()
        {
            InitializeComponent();
            foreach (IPAddress ip in Dns.GetHostByName(Dns.GetHostName()).AddressList)
            {
                My_IP.Text = "IP " + ip.ToString();
            }
            server_t = new Server_IP();
            client_t = new Client_IP(client, server_t);            
            c_s = new Connect_Client("IP_server");
        }

        private void Start_S_Click(object sender, RoutedEventArgs e)
        {
            server_t.Listen();
        }
    }
}
