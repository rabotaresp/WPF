﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace TCP_IP_connect
{
    public class Client_IP
    {            
            protected internal string Id { get; private set; }
            protected internal NetworkStream Stream { get; private set; }
            string message;
            public string Message { get => message; set => message = value; }
            string userName;
            TcpClient client;
            Server_IP server; // объект сервера

            public Client_IP(TcpClient tcpClient, Server_IP serverObject)
            {
                Id = Guid.NewGuid().ToString();
                client = tcpClient;
                server = serverObject;
                serverObject.AddConnection(this);
            }

            public void Process()
            {
                try
                {
                    Stream = client.GetStream();
                    // получаем имя пользователя
                    Message = GetMessage();
                    userName = Message;

                    Message = userName + "подключился к игре";
                    // посылаем сообщение о входе в чат всем подключенным пользователям
                    server.BroadcastMessage(Message, this.Id);
                    MessageBox.Show(Message);
                    // в бесконечном цикле получаем сообщения от клиента
                    while (true)
                    {
                        try
                        {
                            Message = GetMessage();
                            Message = String.Format("{0}: {1}", userName, Message);
                            MessageBox.Show(Message);
                            server.BroadcastMessage(Message, this.Id);
                        }
                        catch
                        {
                            Message = String.Format("{0}: покинул чат", userName);
                            MessageBox.Show(Message);
                            server.BroadcastMessage(Message, this.Id);
                            break;
                        }
                    }
                }
                catch (Exception e)
                {
                    MessageBox.Show(e.Message);
                }
                finally
                {
                    // в случае выхода из цикла закрываем ресурсы
                    server.RemoveConnection(this.Id);
                    Close();
                }
            }

            // чтение входящего сообщения и преобразование в строку
            private string GetMessage()
            {
                byte[] data = new byte[64]; // буфер для получаемых данных
                StringBuilder builder = new StringBuilder();
                int bytes = 0;
                do
                {
                    bytes = Stream.Read(data, 0, data.Length);
                    builder.Append(Encoding.Unicode.GetString(data, 0, bytes));
                }
                while (Stream.DataAvailable);

                return builder.ToString();
            }

            // закрытие подключения
            protected internal void Close()
            {
                if (Stream != null)
                    Stream.Close();
                if (client != null)
                    client.Close();
            }
        }
}
