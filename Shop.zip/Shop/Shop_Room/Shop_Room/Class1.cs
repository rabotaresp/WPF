﻿using System;

namespace Shop_Room
{
    public class Class1
    {
    }
}
