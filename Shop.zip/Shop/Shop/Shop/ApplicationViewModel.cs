﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Shop
{
    class ApplicationViewModel : INotifyPropertyChanged
    {
        private Item selectedPhone;
        Basket basket;
        
        // команда добавления нового объекта
        private Cust_Command addCommand;
        public Cust_Command AddCommand
        {
            get
            {
                return addCommand ??
                  (addCommand = new Cust_Command(obj =>
                  {
                      Item phone = obj as Item;
                      if (phone != null)
                          MessageBox.Show(phone.Title);
                      Basket.Items_Basket.Add(phone);
                      MessageBox.Show("Add");
                      //Items.Insert(0, phone);
                      SelectedPhone = phone;
                  }));
            }
        }
        // команда удаления
        private Cust_Command removeCommand;
        public Cust_Command RemoveCommand
        {
            get
            {
                return removeCommand ??
                  (removeCommand = new Cust_Command(obj =>
                  {
                      Item phone = obj as Item;
                      if (phone != null)
                      {
                          Items.Remove(phone);
                          Basket.Items_Basket.Add(phone);
                          MessageBox.Show("Remove_Phone");
                      }
                  },
                 (obj) => Items.Count > 0));
            }
        }


        public ObservableCollection<Item> Items { get; set; }
       
        public Item SelectedPhone
        {
            get { return selectedPhone; }
            set
            {
                selectedPhone = value;
                OnPropertyChanged("SelectedPhone");
            }
        }

        internal Basket Basket { get => basket; set => basket = value; }

        public ApplicationViewModel()
        {
            Items = new ObservableCollection<Item>
            {
                new Item { Title="iPhone 7", Company="Apple", Price=56000 },
                new Item {Title="Galaxy S7 Edge", Company="Samsung", Price =60000 },
                new Item {Title="Elite x3", Company="HP", Price=56000 },
                new Item {Title="Mi5S", Company="Xiaomi", Price=35000 }
            };

            basket = new Basket();

        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
