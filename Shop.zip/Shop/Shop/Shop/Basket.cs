﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Shop
{
    class Basket : INotifyPropertyChanged
    {
        private ObservableCollection<Item> items_Basket;
        private int count;
        private int price_total;
        public Basket()
        {
            items_Basket = new ObservableCollection<Item>();
        }
       
        public int Price_total
        {
            get { return price_total; }
            set
            {
                price_total = value;
                OnPropertyChanged("Price");
            }
        }
        public int Count
        {
            get { return count; }
            set
            {
                count = value;
                OnPropertyChanged("Count");
            }
        }
        public ObservableCollection<Item> Items_Basket
        {
            get { return items_Basket; }
            set
            {
                items_Basket = value;
                OnPropertyChanged("Items_Basket");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged([CallerMemberName]string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
