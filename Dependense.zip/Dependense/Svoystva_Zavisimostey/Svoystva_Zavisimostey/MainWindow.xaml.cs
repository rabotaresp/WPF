﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Svoystva_Zavisimostey
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        My_Size obj;
        public MainWindow()
        {
            InitializeComponent();
            obj = new My_Size();
            Binding binding = new Binding();
            Binding binding1 = new Binding();

            binding.Source = obj;
            binding1.Source = obj;

            binding.Path = new PropertyPath("size_h");
            binding1.Path = new PropertyPath("size_w");

            binding.Mode = BindingMode.TwoWay;
            binding1.Mode = BindingMode.TwoWay;

            Cust_ellips.SetBinding(Ellipse.HeightProperty, binding);
            Cust_ellips.SetBinding(Ellipse.WidthProperty, binding1);

            Size_ellips_h.SetBinding(TextBox.TextProperty, binding);
            Size_ellips_w.SetBinding(TextBox.TextProperty, binding1);

            Cust_ellips.Fill = new SolidColorBrush(Colors.Aqua);
        }
    }
}
