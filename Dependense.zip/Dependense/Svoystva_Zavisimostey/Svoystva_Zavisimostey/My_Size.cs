﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace Svoystva_Zavisimostey
{
   public class My_Size : DependencyObject
    { 
        public static readonly DependencyProperty sizeProperty_h;
        public static readonly DependencyProperty sizeProperty_w;

        static My_Size()
        {
            FrameworkPropertyMetadata heightvalidator = new FrameworkPropertyMetadata();
            heightvalidator.CoerceValueCallback = new CoerceValueCallback(Correct_h);

            FrameworkPropertyMetadata weightvalidator = new FrameworkPropertyMetadata();
            weightvalidator.CoerceValueCallback = new CoerceValueCallback(Correct_w);

            sizeProperty_h = DependencyProperty.Register("size_h", typeof(double), typeof(My_Size), heightvalidator, new ValidateValueCallback(Validate_h));
            sizeProperty_w = DependencyProperty.Register("size_w", typeof(double), typeof(My_Size), weightvalidator, new ValidateValueCallback(Validate_w));
        }

        public double size_h
        {
            get { return (double)GetValue(sizeProperty_h); }
            set { SetValue(sizeProperty_h, value); }
        }

        public double size_w
        {
            get { return (double)GetValue(sizeProperty_w); }
            set { SetValue(sizeProperty_w, value); }
        }

        private static bool Validate_h(object value)
        {
            double currentValue = (double)value;
            if(currentValue == 0)
            {
                return true;
            }
            if (currentValue <= 150)
            {
                return true;
            }
            return false;
        }
        private static bool Validate_w(object value)
        {
            double currentValue = (double)value;
            if (currentValue == 0)
            {
                return true;
            }
            if (currentValue <= 150)
            {
                return true;
            }
            return false;
        }
        private static object Correct_h(DependencyObject e, object baseValue)
        {
            double currentValue = (double)baseValue;
            if(currentValue < 10)
            {
                return 10.0;
            }
            return currentValue;
        }
        private static object Correct_w(DependencyObject e, object baseValue)
        {
            double currentValue = (double)baseValue;
            if (currentValue < 10)
            {
                return 10.0;
            }
            return currentValue;
        }
    }
}
